getwd()
install.packages("e1071")
install.packages("caret")
install.pack("rpart")
install.packages("rpart")
library(e1071)
library(caret)
library(rpart)
library(lattice)
library(ggplot2)
###imported libraries into R needed for this project
#############Brooke Woods Project 3 : SAS Simulation & R Project
setwd()
getwd()
###set by directory where i wanted it
setwd("C:\\Users\\18174\\SASSimulationStudio\\Multi-QueueProblem-Brooke"
getwd()
set.seed(123)

#read in csv files I created from SAS results 
dataset1 <- read.csv("Server5Results.csv")
dataset2 <- read.csv("Server6Results.csv")


#created summary stats for wait and length in queue
CombinedDataSet <- rbind.data.frame(dataset1,dataset2)
CombinedDataSet
summary(dataset1[,(ncol(dataset1)-5):ncol(dataset1], digits = 3)
summary(dataset2[,(ncol(dataset2)-5):ncol(dataset2)], digits = 3)
                       
#change number of servers to five and six
sapply(CombinedDataSet, class)
CombinedDataSet$PointName <- ifelse(CombinedDataSet$PointName == "Five Server",5,6) 
names(CombinedDataSet)[1] <- "NumberServers"
drops <- c("StartTime","EndTime")   #drop start time and end time
CombinedDataSet <- CombinedDataSet[ , !(names(CombinedDataSet) %in% drops)]
View(CombinedDataSet)   #view dataset 
dim(CombinedDataSet)   #get dimensions of new dataset
                       
#####CREATE A Training Data set with 40% of the observations and the rest in VALIDATION DATA SET 
validation_index <- createDataPartition(CombinedDataSet$NumberServers, p=0.40, list=FALSE)
validation <- CombinedDataSet[-validation_index,]
Training <- CombinedDataSet[validation_index,]

#here we can view our validation and training data                       
View(validation)
View(Training)

#look at % for number of servers
percentage <- prop.table(table(validation$NumberServers))
percentage #call it to show results 
                       
#scale training data 
ScaledTraining <- Training
ScaledTraining[-1] <- scale(ScaledTraining[-1])
                       
 #scale validation data
ScaledValidation <- validation
ScaledValNumberServers~.,idation[-1] <-scale(ScaledValidation[-1]) 
                       
#put training and validation on head to show first 5 rows
head(ScaledTraining)
head(ScaledValidation)
                       
#training classification using the cvm method
classifier <- svm(formula =NumberServers~.,
                          data = ScaledTraining,
                          type = "C-classification",
                          kernel = "linear", probability = TRUE)
y_pred <- predict(classifier, newdata = ScaledValidation[-1],probability = TRUE) 
head(y_pred)
cm <- table(Actual=ScaledValidation[,1], Predicted=y_pred) 
cm  
                       
#create grid data for Q1 Length (second variable) and Q1 Averge Wait (fifth variable                       
Myset = ScaledValidation
X1 = 0
X2 = seq(min(Myset[, 2]) - 1, max(Myset[, 2]) + 1, by = 0.01) 
X3 = 0
X4 = 0
X5 = seq(min(Myset[, 5]) - 1, max(Myset[, 5]) + 1, by = 0.01) 
X6 = 0
grid_set <- expand.grid(X1, X2, X3, X4,X5,X6) 
colnames(grid_set) = c('InventoryStation1', 'InventoryStation2', 'InventoryStation3','TimeInStation1', 'TimeInStation2', 'TimeInStation3') 
View(Myset)   #view the grid data 
                       
#### y_grid_predicted is predicted values for the data in grid_set
####Plot InventoryStation2 and TimeInStation2 and include the predicted values of  
y_grid_predicted <- predict(classifier, newdata = grid_set) 
head(y_grid_predicted)
plot(Myset[,c(3,6)],main ="SVM(Validation set)", xlab = 'Queue Length',
ylab = 'Average Waiting Time', xlim = range(X2), ylim = range(X5))
contour(X2, X5, matrix(as.numeric(y_grid_predicted), length(X2), length(X5)), add = TRUE) 
                       
####Points are colored either coral or aquamarine for the points in the grid_set
####pch stands for "plot character"
points(grid_set[,c(2,5)], pch = '.', col = ifelse(y_grid_predicted == 5, 'coral1', 'aquamarine')) 
                       
####Points are colored either red or green for the points in Myset
####pch = 21 is a filled circle. bg stands for background
points(Myset[,c(2,5)], pch = 21, bg = ifelse(Myset[, 1] == 5, 'red3','green4'))
legend(x="topleft",legend=c("5 Server","6 Server"), col=c("red3","green4"),pch = 16)
####quit function 
quit

                       
                       
                       
                       
                       
                       
                       